## top-level submission file


"""
    f(a, b) = c
A function that adds the inputs `a` and `b`
"""
function f(a, b)
    # write your code here. Remember to return the sum of a and b!
end
